#include <stdio.h>
#include <stdlib.h>
#include "linkedList.h"

int main(void)
{
	
	while (1)
	{
		Menu();
		KeyDown();

		system("pause");
		system("cls");
	}
	system("pause");
	return 0;
}
