#include <stdio.h>
#include <stdlib.h>
#include "sort.h"
#include <windows.h>
void keysort(int*ax,int*px)
{
	int i;
	double d;
	LARGE_INTEGER Freg;
	LARGE_INTEGER Count1, Count2;
	int a,ch;
	scanf("%d", &a);

	if ((ch = getchar()) == '\n')
	{
		switch (a)
		{
		case 0:
			printf("�˳��˵�\n");
			system("pause");
			exit(0);
		case 1:
			printf("����ǰ\n");
			Print(ax, maxsize);
			QueryPerformanceFrequency(&Freg);
			QueryPerformanceCounter(&Count1);
			insertSort(ax, maxsize);
			QueryPerformanceCounter(&Count2);  // ��ȡʱ���  
			d = (double)(Count2.QuadPart - Count1.QuadPart) / (double)Freg.QuadPart* 1000.0;	
			printf("�����\n");
			Print(ax, maxsize);
			printf("The time is %f s\n", d);
			break;
			
		case 2:
			printf("����ǰ\n");
			Print(ax, maxsize);
			QueryPerformanceFrequency(&Freg);
			QueryPerformanceCounter(&Count1);
			MergeSort(ax, 0, maxsize - 1, temp);
			QueryPerformanceCounter(&Count2);  // ��ȡʱ���  
			d = (double)(Count2.QuadPart - Count1.QuadPart) / (double)Freg.QuadPart * 1000.0;
			printf("�����\n");
			Print(ax, maxsize);
			printf("The time is %f s\n", d);
			break;
		case 3:
			printf("����ǰ\n");
			Print(ax, maxsize);
			QueryPerformanceFrequency(&Freg);
			QueryPerformanceCounter(&Count1);
			QuickSort_Recursion(ax, 0, maxsize - 1);
			QueryPerformanceCounter(&Count2);  // ��ȡʱ���  
			d = (double)(Count2.QuadPart - Count1.QuadPart) / (double)Freg.QuadPart * 1000.0;
			printf("�����\n");
			Print(ax, maxsize);
			printf("The time is %f s\n", d);
			break;
		case 4:
			printf("����ǰ\n");
			Print(ax, maxsize);
			QueryPerformanceFrequency(&Freg);
			QueryPerformanceCounter(&Count1);
			Partition(ax, 0, maxsize - 1);
			QuickSort_Recursion(ax, 0, maxsize - 1);
			QueryPerformanceCounter(&Count2);  // ��ȡʱ���  
			d = (double)(Count2.QuadPart - Count1.QuadPart) / (double)Freg.QuadPart * 1000.0;
			printf("�����\n");
			Print(ax, maxsize);
			printf("The time is %f s\n", d);
			break;
		case 5:
			printf("����ǰ\n");
			Print(ax, maxsize);
			QueryPerformanceFrequency(&Freg);
			QueryPerformanceCounter(&Count1);
			CountSort(ax, maxsize, max);
			QueryPerformanceCounter(&Count2);  // ��ȡʱ���  
			d = (double)(Count2.QuadPart - Count1.QuadPart) / (double)Freg.QuadPart * 1000.0;
			printf("�����\n");
			Print(ax, maxsize);
			printf("The time is %f s\n", d);
			break;
		case 6:
			printf("����ǰ\n");
			Print(ax, maxsize);
			QueryPerformanceFrequency(&Freg);
			QueryPerformanceCounter(&Count1);
			RadixCountSort(ax, maxsize);
			QueryPerformanceCounter(&Count2);  // ��ȡʱ���  
			d = (double)(Count2.QuadPart - Count1.QuadPart) / (double)Freg.QuadPart * 1000.0;
			printf("�����\n");
			Print(ax, maxsize);
			printf("The time is %f s\n", d);
			break;
		case 7:
			printf("����ǰ\n");
			Print(px, maxsize);
			ColorSort(px, maxsize);
			printf("�����\n");
			Print(px, maxsize);
			break;

		default:
			printf("��������������\n");
			break;
		}
	}
	else
	{
		rewind(stdin);
		printf("������������������\n");
	}	
	
}